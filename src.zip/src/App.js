
import './App.css';
import QuestionForm from './components/QuestionForm';




function App() {
  return (
    <div className="App">
      <QuestionForm />
    </div>
  );
}

export default App;

